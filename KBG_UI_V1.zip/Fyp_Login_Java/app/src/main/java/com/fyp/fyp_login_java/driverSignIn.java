package com.fyp.fyp_login_java;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class driverSignIn extends AppCompatActivity {

    public static String PREFS_NAME= "MyPrefsFile";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_sign_in);


        TextView username= findViewById(R.id.driver_username);
        TextView password= findViewById(R.id.driver_password);

        MaterialButton driverloginbtn= (MaterialButton) findViewById(R.id.driverloginbtn);

        driverloginbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                if(username.getText().toString().equals("driver") && password.getText().toString().equals("driver"))
                {
                    //SavingSignIn
                    SharedPreferences sharedPreferences = getSharedPreferences(driverSignIn.PREFS_NAME,0);
                    SharedPreferences.Editor editor= sharedPreferences.edit();
                    editor.putBoolean("hasLoggedIn",true);
                    editor.commit();

                    //correct
                    Toast.makeText(driverSignIn.this,"Login Successful", Toast.LENGTH_SHORT ).show();
                    Intent intent = new Intent(driverSignIn.this,userMenu.class);
                    startActivity(intent);
                    finish();
                }
                else
                {
                    //incorrect
                    Toast.makeText(driverSignIn.this,"Login Failed/ Incorrect Password", Toast.LENGTH_SHORT ).show();
                }

            }

        });


    }
}