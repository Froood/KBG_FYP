package com.fyp.fyp_login_java;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class feedbackPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback_page);


        MaterialButton btnfeedbacksubmit= (MaterialButton) findViewById(R.id.button_submit);
        btnfeedbacksubmit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Toast.makeText(feedbackPage.this,"Complaint Submitted", Toast.LENGTH_SHORT ).show();
                Intent intent = new Intent(feedbackPage.this,userMenu.class);
                startActivity(intent);
                finish();
            }
        });
    }
}