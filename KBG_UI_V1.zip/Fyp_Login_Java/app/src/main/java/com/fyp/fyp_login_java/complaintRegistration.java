package com.fyp.fyp_login_java;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.media.Image;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;


public class complaintRegistration extends AppCompatActivity {

    private final int CAMERA_REQ_CODE = 100;
    ImageView imgCamera;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complaint_registration);

        MaterialButton btncmpsubmit= (MaterialButton) findViewById(R.id.button_submit);
        btncmpsubmit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Toast.makeText(complaintRegistration.this,"Complaint Submitted", Toast.LENGTH_SHORT ).show();
                Intent intent = new Intent(complaintRegistration.this,userMenu.class);
                startActivity(intent);
                finish();
            }
        });

        imgCamera = findViewById(R.id.image_view_preview);
        Button btnCamera = findViewById(R.id.button_takePhoto);

        btnCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent iCamera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(iCamera, CAMERA_REQ_CODE);


            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode== RESULT_OK)  {

                if(requestCode== CAMERA_REQ_CODE)
                {//for camera
                  Bitmap img =  (Bitmap)(data.getExtras().get("data"));
                    imgCamera.setImageBitmap(img);
                }
        }

    }
}