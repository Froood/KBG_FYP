package com.fyp.fyp_login_java;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class userMenu extends AppCompatActivity {

    public static String PREFS_NAME= "MyPrefsFile";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_menu);

        MaterialButton btncmppage= (MaterialButton) findViewById(R.id.button_go_complaintPage);
        btncmppage.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                Intent intent = new Intent(userMenu.this,complaintRegistration.class);
                startActivity(intent);
                finish();
            }

        });
        MaterialButton btnfeedback= (MaterialButton) findViewById(R.id.button5);
        btnfeedback.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                Intent intent = new Intent(userMenu.this,feedbackPage.class);
                startActivity(intent);
                finish();
            }

        });

        MaterialButton signOut= (MaterialButton) findViewById(R.id.signOutBtn);
        signOut.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                //RemovingSignIn
                SharedPreferences sharedPreferences = getSharedPreferences(driverSignIn.PREFS_NAME,0);
                SharedPreferences.Editor editor= sharedPreferences.edit();
                editor.putBoolean("hasLoggedIn",false);
                editor.commit();
                //Toast
                Toast.makeText(userMenu.this, "Signed Out", Toast.LENGTH_SHORT).show();
                //
                Intent intent = new Intent(userMenu.this,signin_signup_choice.class);
                startActivity(intent);
                finish();
            }

        });


    }




}