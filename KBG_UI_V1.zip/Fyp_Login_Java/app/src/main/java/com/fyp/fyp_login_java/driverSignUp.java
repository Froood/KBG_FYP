package com.fyp.fyp_login_java;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class driverSignUp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_sign_up);
    }
}